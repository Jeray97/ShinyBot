package com.soulshinygame.bot.admin;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Captura los logs del bot en un buffer circular en memoria
 * para mostrarlos en tiempo real en el panel de administración.
 *
 * Se conecta a Logback como un Appender adicional.
 */
public class AdminLogHandler {

    private static final int MAX_LOGS = 500;
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault());

    private final Deque<LogEntry> buffer = new ArrayDeque<>();

    public AdminLogHandler() {
        attachToLogback();
    }

    private void attachToLogback() {
        try {
            LoggerContext ctx = (LoggerContext) LoggerFactory.getILoggerFactory();
            Logger root       = ctx.getLogger(Logger.ROOT_LOGGER_NAME);

            AppenderBase<ILoggingEvent> appender = new AppenderBase<>() {
                @Override
                protected void append(ILoggingEvent event) {
                    String level = event.getLevel().toString();
                    String msg   = event.getFormattedMessage();
                    String time  = FMT.format(Instant.ofEpochMilli(event.getTimeStamp()));
                    String logger = event.getLoggerName();
                    // Acortar el nombre del logger
                    if (logger.contains(".")) logger = logger.substring(logger.lastIndexOf('.') + 1);

                    synchronized (buffer) {
                        if (buffer.size() >= MAX_LOGS) buffer.pollFirst();
                        buffer.addLast(new LogEntry(time, level, logger, msg));
                    }
                }
            };

            appender.setContext(ctx);
            appender.start();
            root.addAppender(appender);

        } catch (Exception e) {
            // Si no está Logback (usa slf4j-simple), no pasa nada — los logs no aparecerán en el panel
            System.err.println("AdminLogHandler: no se pudo conectar a Logback: " + e.getMessage());
        }
    }

    /** Devuelve los últimos N logs como JSON array */
    public String getLogsJson(int limit) {
        List<LogEntry> copy;
        synchronized (buffer) {
            copy = new ArrayList<>(buffer);
        }

        int from = Math.max(0, copy.size() - limit);
        StringBuilder sb = new StringBuilder("[");
        for (int i = from; i < copy.size(); i++) {
            LogEntry e = copy.get(i);
            sb.append(String.format(
                    "{\"time\":\"%s\",\"level\":\"%s\",\"logger\":\"%s\",\"msg\":%s}",
                    e.time, e.level, e.logger, jsonString(e.msg)));
            if (i < copy.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    private String jsonString(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "") + "\"";
    }

    private record LogEntry(String time, String level, String logger, String msg) {}
}